"""
SolidWorks 零件建模工具
提供草图绘制和特征创建的常用函数
"""
import win32com.client
import pythoncom
from win32com.client import VARIANT
from contextlib import contextmanager

PLANE_NAME_ALIASES = {
    "Front Plane": ["Front Plane", "前视基准面"],
    "Top Plane": ["Top Plane", "上视基准面"],
    "Right Plane": ["Right Plane", "右视基准面"],
    "前视基准面": ["前视基准面", "Front Plane"],
    "上视基准面": ["上视基准面", "Top Plane"],
    "右视基准面": ["右视基准面", "Right Plane"],
}

SKETCH_NAME_PREFIX_ALIASES = {
    "Sketch": "草图",
    "草图": "Sketch",
}


# ============================================================
# 草图操作
# ============================================================

def _empty_callout():
    """创建兼容 SelectByID2 的空 Callout 参数。"""
    return VARIANT(pythoncom.VT_DISPATCH, None)


def _select_by_id(extension, entity_name, entity_type, append=False, mark=0):
    """
    统一封装 SelectByID2，避免 None 在部分 SolidWorks 版本中触发类型不匹配。

    参数:
        extension: ModelDocExtension 对象
        entity_name: 实体名称
        entity_type: 实体类型字符串
        append: 是否追加选择
        mark: 选择标记

    返回:
        bool
    """
    return extension.SelectByID2(
        entity_name, entity_type, 0, 0, 0, append, mark, _empty_callout(), 0
    )


def _get_plane_name_candidates(plane_name):
    """
    获取基准面的候选名称列表

    参数:
        plane_name: 用户提供的基准面名称

    返回:
        list[str]
    """
    return PLANE_NAME_ALIASES.get(plane_name, [plane_name])


def _get_sketch_name_candidates(sketch_name):
    """
    获取草图名称候选列表，自动兼容中英文前缀。

    参数:
        sketch_name: 草图名称

    返回:
        list[str]
    """
    candidates = [sketch_name]
    for prefix, alias in SKETCH_NAME_PREFIX_ALIASES.items():
        if sketch_name.startswith(prefix):
            alias_name = alias + sketch_name[len(prefix):]
            if alias_name not in candidates:
                candidates.append(alias_name)
    return candidates


def _select_first_candidate(extension, candidate_names, entity_type, append=False, mark=0):
    """
    按候选名称列表依次尝试选择实体。

    参数:
        extension: ModelDocExtension 对象
        candidate_names: 候选名称列表
        entity_type: 实体类型字符串
        append: 是否追加选择
        mark: 选择标记

    返回:
        str | None
    """
    for candidate_name in candidate_names:
        if _select_by_id(extension, candidate_name, entity_type, append=append, mark=mark):
            return candidate_name
    return None


def _get_selection_count(model):
    """
    获取当前选择集中的对象数量。

    参数:
        model: IModelDoc2 对象

    返回:
        int
    """
    selection_manager = model.SelectionManager
    count_member = getattr(selection_manager, "GetSelectedObjectCount2")
    return count_member(-1) if callable(count_member) else int(count_member)


def _ensure_sketch_selected(model, sketch_name):
    """
    确保拉伸/切除前已有可用的草图选择。

    参数:
        model: IModelDoc2 对象
        sketch_name: 草图名称

    返回:
        str
    """
    if _get_selection_count(model) > 0:
        return "__current_selection__"

    selected_sketch = _select_first_candidate(
        model.Extension, _get_sketch_name_candidates(sketch_name), "SKETCH"
    )
    if not selected_sketch:
        raise ValueError(f"无法选择草图: {sketch_name}")
    return selected_sketch

def start_sketch(model, plane_name="Front Plane"):
    """
    在指定基准面上开始草图

    参数:
        model: IModelDoc2
        plane_name: 基准面名称
            英文: "Front Plane", "Top Plane", "Right Plane"
            中文: "前视基准面", "上视基准面", "右视基准面"
    """
    model.ClearSelection2(True)

    selected_plane = _select_first_candidate(
        model.Extension, _get_plane_name_candidates(plane_name), "PLANE"
    )
    if selected_plane:
        model.SketchManager.InsertSketch(True)
        return selected_plane

    raise ValueError(f"无法选择基准面: {plane_name}")


def end_sketch(model):
    """退出当前草图"""
    model.SketchManager.InsertSketch(True)


@contextmanager
def sketch(model, plane_name="Front Plane"):
    """
    草图上下文管理器。

    示例:
        with sketch(model, "Front Plane") as sketch_name:
            sketch_circle(model, 0, 0, mm(25))
        extrude_boss(model, sketch_name, mm(50))
    """
    start_sketch(model, plane_name)
    try:
        yield current_sketch_name(model)
    finally:
        end_sketch(model)


def current_sketch_name(model, fallback="Sketch1"):
    """
    获取当前草图名称。

    参数:
        model: IModelDoc2
        fallback: 无法读取当前草图时返回的默认名称
    """
    active_sketch = model.SketchManager.ActiveSketch
    if active_sketch:
        return active_sketch.Name
    return fallback


def sketch_line(model, x1, y1, x2, y2):
    """画直线（单位: 米）"""
    return model.SketchManager.CreateLine(x1, y1, 0, x2, y2, 0)


def sketch_rectangle(model, cx, cy, w, h):
    """以中心点画矩形（单位: 米）"""
    return model.SketchManager.CreateCenterRectangle(
        cx, cy, 0, cx + w / 2, cy + h / 2, 0
    )


def sketch_corner_rectangle(model, x1, y1, x2, y2):
    """以对角线画矩形（单位: 米）"""
    return model.SketchManager.CreateCornerRectangle(x1, y1, 0, x2, y2, 0)


def sketch_circle(model, cx, cy, radius):
    """画圆（单位: 米）"""
    return model.SketchManager.CreateCircleByRadius(cx, cy, 0, radius)


def sketch_arc(model, cx, cy, x1, y1, x2, y2, direction=1):
    """
    画圆弧

    参数:
        cx, cy: 圆心坐标（米）
        x1, y1: 起点坐标
        x2, y2: 终点坐标
        direction: 1=逆时针, -1=顺时针
    """
    return model.SketchManager.CreateArc(cx, cy, 0, x1, y1, 0, x2, y2, 0, direction)


def sketch_polygon(model, cx, cy, radius, sides=6):
    """画正多边形（内切圆方式）"""
    return model.SketchManager.CreatePolygon(cx, cy, 0, cx + radius, cy, 0, sides, True)


def sketch_slot(
    model,
    x1,
    y1,
    x2,
    y2,
    x3,
    y3,
    width,
    slot_creation_type=0,
    slot_length_type=0,
    center_arc_direction=1,
    add_dimension=False,
):
    """画槽口"""
    return model.SketchManager.CreateSketchSlot(
        slot_creation_type,
        slot_length_type,
        width,
        x1, y1, 0,
        x2, y2, 0,
        x3, y3, 0,
        center_arc_direction,
        add_dimension,
    )


def sketch_spline(model, points, simulate_natural_ends=False):
    """
    画样条曲线

    参数:
        points: [(x1,y1), (x2,y2), ...] 控制点列表（单位: 米）
    """
    import array
    point_array = array.array('d')
    for x, y in points:
        point_array.extend([x, y, 0.0])
    return model.SketchManager.CreateSpline2(point_array, simulate_natural_ends)


def sketch_point(model, x, y, z=0.0):
    """画草图点（单位: 米）"""
    return model.SketchManager.CreatePoint(x, y, z)


def sketch_text(
    model,
    text,
    x,
    y,
    z=0.0,
    alignment=0,
    flip_direction=0,
    horizontal_mirror=0,
    width_factor=100,
    space_between_chars=100,
):
    """
    插入草图文字。

    参数:
        text: 文本内容
        x, y, z: 文字起点坐标（米）
        alignment: 0=左对齐, 1=居中, 2=右对齐, 3=两端对齐
    """
    return model.InsertSketchText(
        x,
        y,
        z,
        text,
        alignment,
        flip_direction,
        horizontal_mirror,
        width_factor,
        space_between_chars,
    )


def add_dimension(model, x, y):
    """在指定位置添加尺寸标注"""
    return model.AddDimension2(x, y, 0)


def add_sketch_relation(model, relation_type):
    """
    添加草图几何关系

    常用 relation_type:
        "sgFIXED", "sgHORIZONTAL", "sgVERTICAL", "sgCOLINEAR",
        "sgPARALLEL", "sgPERPENDICULAR", "sgTANGENT", "sgCONCENTRIC",
        "sgEQUAL", "sgSYMMETRIC", "sgMIDPOINT", "sgCOINCIDENT"
    """
    return model.SketchAddConstraints(relation_type)


# ============================================================
# 特征操作
# ============================================================

def extrude_boss(model, sketch_name, depth, direction=True, merge=True):
    """
    凸台拉伸

    参数:
        model: IModelDoc2
        sketch_name: 草图名称（如 "Sketch1"）
        depth: 拉伸深度（米）
        direction: True=正方向
        merge: True=合并结果
    """
    _ensure_sketch_selected(model, sketch_name)
    return model.FeatureManager.FeatureExtrusion3(
        True,         # Sd: 单向拉伸
        False,        # Flip
        direction,    # Dir: 拉伸方向
        0,            # T1: Blind
        0,            # T2: Blind
        depth,        # D1
        0.0,          # D2
        False,        # Dchk1
        False,        # Dchk2
        False,        # Ddir1
        False,        # Ddir2
        0.0,          # Dang1
        0.0,          # Dang2
        False,        # OffsetReverse1
        False,        # OffsetReverse2
        False,        # TranslateSurface1
        False,        # TranslateSurface2
        merge,        # Merge
        False,        # UseFeatScope
        True,         # UseAutoSelect
        0,            # T0: 从草图平面开始
        0.0,          # StartOffset
        False         # FlipStartOffset
    )


def extrude_cut(model, sketch_name, depth, direction=True, flip=False):
    """
    切除拉伸

    参数:
        model: IModelDoc2
        sketch_name: 草图名称
        depth: 切除深度（米），0 表示完全贯穿
        direction: True=正方向
        flip: True=翻转切除方向
    """
    _ensure_sketch_selected(model, sketch_name)
    if depth == 0:
        # 完全贯穿 - 使用 OneDir
        return model.FeatureManager.FeatureCut4(
            True,    # SingleDir
            False,   # Flip
            False,   # BothDirections
            1,       # EndCondition: swEndCondThroughAll = 1
            0,       # ProfileThin
            0.01,    # Depth (占位值，贯穿时不使用)
            0,       # DraftAngle
            False,   # DraftOutward
            False,   # reverseDirection
            False,   # CappedDiameter
            0,       # OffsetFromSurface
            0.0,     # OffsetDistance
            False,   # TranslateSurface1
            False,   # TranslateSurface2
            False,   # Merge
            False,   # UseFeatScope
            True,    # UseAutoSelect
            1,       # Direction
            True,    # KeepCapped
            0, 0, 0, 0, False, False, False, False
        )
    else:
        # 有限深度
        return model.FeatureManager.FeatureCut4(
            True,    # SingleDir
            False,   # Flip
            False,   # BothDirections
            0,       # EndCondition: swEndCondBlind = 0
            0,       # ProfileThin
            depth,   # Depth
            0,       # DraftAngle
            False,   # DraftOutward
            False,   # reverseDirection
            False,   # CappedDiameter
            0,       # OffsetFromSurface
            0.0,     # OffsetDistance
            False,   # TranslateSurface1
            False,   # TranslateSurface2
            False,   # Merge
            False,   # UseFeatScope
            True,    # UseAutoSelect
            1,       # Direction
            True,    # KeepCapped
            0, 0, 0, 0, False, False, False, False
        )


def extrude_midplane(model, sketch_name, total_depth):
    """
    中面拉伸（两侧对称拉伸）

    参数:
        total_depth: 总深度（米），每侧为 total_depth/2
    """
    _ensure_sketch_selected(model, sketch_name)
    return model.FeatureManager.FeatureExtrusion3(
        True,         # Sd: 单向定义，终止条件控制为中面
        False,        # Flip
        True,         # Dir
        6,            # T1: swEndCondMidPlane
        0,            # T2
        total_depth,  # D1
        0.0,          # D2
        False,        # Dchk1
        False,        # Dchk2
        False,        # Ddir1
        False,        # Ddir2
        0.0,          # Dang1
        0.0,          # Dang2
        False,        # OffsetReverse1
        False,        # OffsetReverse2
        False,        # TranslateSurface1
        False,        # TranslateSurface2
        True,         # Merge
        False,        # UseFeatScope
        True,         # UseAutoSelect
        0,            # T0
        0.0,          # StartOffset
        False         # FlipStartOffset
    )


def revolve_boss(model, sketch_name, angle_rad, axis_sketch_name=None):
    """
    旋转凸台

    参数:
        sketch_name: 轮廓草图名称
        angle_rad: 旋转角度（弧度），2*pi 表示 360 度
        axis_sketch_name: 旋转轴草图名称（None 则需预先选择轴线）
    """
    _ensure_sketch_selected(model, sketch_name)
    return model.FeatureManager.FeatureRevolve2(
        True, True, False,
        False, False, False,
        0, 0,
        angle_rad, 0,
        False, False,
        0.0, 0.0,
        0, 0, 0, True, True, True
    )


def fillet(model, radius, edges=None):
    """
    倒圆角

    参数:
        model: IModelDoc2
        radius: 圆角半径（米）
        edges: 预先选择的边线列表，None 则使用当前选择
    """
    # 使用 FeatureFillet（兼容 SolidWorks 2024 R2）
    return model.FeatureManager.FeatureFillet(195, radius, 0, 0, None, None, None)


def chamfer(model, distance, angle_deg=45):
    """
    倒角

    参数:
        distance: 倒角距离（米）
        angle_deg: 倒角角度（度）
    """
    import math
    angle_rad = angle_deg * math.pi / 180.0
    # 使用 InsertFeatureChamfer（兼容 SolidWorks 2024 R2）
    return model.FeatureManager.InsertFeatureChamfer(4, 1, distance, angle_rad, 0, 0, 0, 0)


def linear_pattern(model, feature_name, d1_x, d1_y, d1_z, d1_spacing, d1_count,
                    d2_x=0, d2_y=0, d2_z=0, d2_spacing=0, d2_count=1):
    """
    线性阵列

    参数:
        feature_name: 要阵列的特征名称
        d1_*: 方向1 的方向向量、间距（米）和数量
        d2_*: 方向2（可选）
    """
    _select_by_id(model.Extension, feature_name, "BODYFEATURE", mark=4)
    # 使用 FeatureLinearPattern3
    # 方向向量使用字符串格式
    dir1 = f"{d1_x},{d1_y},{d1_z}"
    dir2 = f"{d2_x},{d2_y},{d2_z}"
    return model.FeatureManager.FeatureLinearPattern3(
        d1_spacing, d2_spacing,
        d1_count, d2_count,
        False, False,  # D1/D2 geometry
        dir1, dir2,
        False, False    # Flip
    )


def circular_pattern(model, feature_name, axis_name, angle_rad, count, equal_spacing=True):
    """
    圆形阵列

    参数:
        feature_name: 要阵列的特征名称
        axis_name: 旋转轴名称
        angle_rad: 总角度（弧度）
        count: 实例数量
        equal_spacing: True=等间距
    """
    _select_by_id(model.Extension, feature_name, "BODYFEATURE", mark=4)
    _select_by_id(model.Extension, axis_name, "AXIS", append=True, mark=1)
    # 使用 FeatureCircularPattern（兼容版本）
    return model.FeatureManager.FeatureCircularPattern(
        count, angle_rad, equal_spacing, True
    )


def shell(model, thickness, faces_to_remove=None):
    """
    抽壳

    参数:
        thickness: 壁厚（米）
        faces_to_remove: 需预先选择要移除的面
    """
    # 使用 InsertFeatureShell（兼容 SolidWorks 2024 R2）
    return model.InsertFeatureShell(thickness, False)


def mirror_feature(model, feature_name, mirror_plane_name):
    """
    镜像特征

    参数:
        feature_name: 要镜像的特征名称
        mirror_plane_name: 镜像基准面名称
    """
    _select_by_id(model.Extension, feature_name, "BODYFEATURE", mark=4)
    _select_by_id(model.Extension, mirror_plane_name, "PLANE", append=True, mark=1)
    return model.FeatureManager.InsertMirrorFeature2(False, False, False, False, 0)


def hole_wizard(model, hole_type, standard, fastener_type, size, depth, x, y, z):
    """
    异型孔向导（简化版）
    注意：完整的异型孔向导参数复杂，建议参考 API 文档调整
    """
    # 异型孔向导需要通过 FeatureManager.HoleWizard5 调用
    # 具体参数取决于孔类型，此处提供框架
    pass


def rib(model, sketch_name, thickness, direction=True):
    """
    筋特征

    参数:
        sketch_name: 筋轮廓草图名称
        thickness: 筋厚度（米）
        direction: 拉伸方向
    """
    _ensure_sketch_selected(model, sketch_name)
    return model.FeatureManager.InsertRib(
        direction, False, thickness, 0, False, False, False, 0, False
    )


def scan(
    model,
    profile_sketch_name,
    path_sketch_name,
    thin=False,
    reverse_direction=False,
    flip_profile=False,
    start_condition=0,
    end_condition=0,
    start_offset=0.0,
    end_offset=0.0,
    show_preview=False,
    use_feat_scope=False,
    use_auto_select=True,
    profile_position=0,
    twist_control=0,
    twist_angle=0,
    start_tangent_length=0.0,
    end_tangent_length=0.0,
    use_start_end_tangents=False,
    show_tangent_preview=False,
):
    """
    扫描特征

    参数:
        profile_sketch_name: 轮廓草图名称
        path_sketch_name: 路径草图名称
    """
    model.ClearSelection2(True)

    # 选择路径
    _select_first_candidate(model.Extension, _get_sketch_name_candidates(path_sketch_name), "SKETCH")
    # 选择轮廓
    _select_first_candidate(
        model.Extension, _get_sketch_name_candidates(profile_sketch_name), "SKETCH", append=True
    )

    # 使用 FeatureScan（兼容版本）
    return model.FeatureManager.FeatureScan(
        True,  # ThinFeature
        False  # ReverseDirection
    )


def loft(
    model,
    profile_sketch_names,
    thin=False,
    reverse_direction=False,
    flip_profiles=False,
    show_preview=False,
    use_feat_scope=False,
    use_auto_select=True,
    start_condition=0,
    end_condition=0,
    start_tangent_length=0.0,
    end_tangent_length=0.0,
    use_start_end_tangents=False,
    guide_curves=None,
    center_line=None,
    center_line_param=0,
    use_center_line=False,
    closed_loft=False,
    periodic=False,
    thin_type=0,
    thin_thickness1=0.0,
    thin_thickness2=0.0,
    start_profile=None,
    end_profile=None,
    tangent_lengths=None,
):
    """
    放样特征

    参数:
        profile_sketch_names: 轮廓草图名称列表，按顺序选择
    """
    model.ClearSelection2(True)

    if not profile_sketch_names:
        raise ValueError("profile_sketch_names 不能为空")

    # 选择第一个轮廓
    first = True
    for sketch_name in profile_sketch_names:
        selected = _select_first_candidate(
            model.Extension,
            _get_sketch_name_candidates(sketch_name),
            "SKETCH",
            append=not first,
        )
        if not selected:
            raise ValueError(f"无法选择放样草图: {sketch_name}")
        first = False

    # 选择引导曲线
    if guide_curves:
        for curve_name in guide_curves:
            _select_first_candidate(model.Extension, _get_sketch_name_candidates(curve_name), "SKETCH", append=True)

    # 选择中心线
    if center_line:
        _select_first_candidate(model.Extension, _get_sketch_name_candidates(center_line), "SKETCH", append=True)

    # 使用 FeatureLoft5
    return model.FeatureManager.FeatureLoft5(
        thin,           # Is Thin
        reverse_direction,  # Reverse Direction
        flip_profiles,  # Flip Profiles
        show_preview,   # Show Preview
        use_feat_scope, # Use Feat Scope
        use_auto_select,# Use Auto Select
        start_condition,    # Start Condition
        end_condition,       # End Condition
        start_tangent_length,   # Start Tangent Length
        end_tangent_length,     # End Tangent Length
        use_start_end_tangents, # Use Start/End Tangents
        guide_curves,          # Guide Curves
        center_line,           # Center Line
        center_line_param,     # Center Line Param
        use_center_line,       # Use Center Line
        closed_loft,           # Closed Loft
        periodic,              # Periodic
        thin_type,             # Thin Type
        thin_thickness1,       # Thin Thickness 1
        thin_thickness2,       # Thin Thickness 2
        start_profile,          # Start Profile
        end_profile,            # End Profile
        tangent_lengths         # Tangent Lengths
    )
