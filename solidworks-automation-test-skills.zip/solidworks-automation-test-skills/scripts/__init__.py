"""
SolidWorks Automation Python helper package.
"""

from .action_library import (
    ACTION_REGISTRY,
    ActionSpec,
    action_registry_as_dict,
    build_json_sequence_template,
    build_python_script_skeleton,
    build_route_matrix,
    get_action,
    list_actions,
    write_action_registry,
)
from .sw_connect import connect_solidworks, deg, mm, new_document, open_document, save_document
from .sw_session import SolidWorksSession, session

__all__ = [
    "SolidWorksSession",
    "ACTION_REGISTRY",
    "ActionSpec",
    "action_registry_as_dict",
    "connect_solidworks",
    "build_json_sequence_template",
    "build_python_script_skeleton",
    "build_route_matrix",
    "deg",
    "get_action",
    "mm",
    "new_document",
    "open_document",
    "list_actions",
    "save_document",
    "session",
    "write_action_registry",
]
