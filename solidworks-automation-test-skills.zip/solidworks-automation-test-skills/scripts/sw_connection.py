#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
SolidWorks 持久连接管理器

提供:
- 单例持久连接
- 心跳检测
- 自动重连
- 连接状态查询
- 线程/异步安全
"""

import sys
import os
import time
import threading
import asyncio
import traceback

# 添加 skill scripts 到路径
SKILL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                         'codex-skills', 'solidworks-automation', 'scripts')
sys.path.insert(0, SKILL_DIR)

import pythoncom
from win32com.client import VARIANT


class SolidWorksConnectionManager:
    """
    SolidWorks 持久连接管理器（单例模式）
    
    特性:
    - 启动时建立连接，保持持久
    - 后台心跳线程每 5 秒检测一次
    - COM 异常时自动重连
    - 异步锁保护并发访问
    """
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance
    
    def __init__(self, visible=True, heartbeat_interval=5.0):
        if self._initialized:
            return
        
        self.visible = visible
        self.heartbeat_interval = heartbeat_interval
        
        # COM 对象
        self.sw = None
        self.model = None
        self.ext = None
        self.fm = None
        self.sm = None
        
        # 状态
        self.connected = False
        self.last_heartbeat = 0
        self.connection_time = None
        self.reconnect_count = 0
        self.error_history = []
        
        # 异步锁
        self._async_lock = asyncio.Lock()
        self._thread_lock = threading.RLock()
        
        # 心跳线程
        self._heartbeat_thread = None
        self._stop_heartbeat = threading.Event()
        
        self._initialized = True
    
    def _e(self):
        return VARIANT(pythoncom.VT_DISPATCH, None)
    
    def _check_com_alive(self):
        """检查 COM 对象是否仍然有效"""
        try:
            if self.sw is None:
                return False
            # 尝试访问一个简单属性来检测 COM 连接
            _ = self.sw.GetProcessID
            return True
        except Exception:
            return False
    
    def _connect(self):
        """建立 SolidWorks 连接"""
        with self._thread_lock:
            try:
                from sw_session import SolidWorksSession
                session = SolidWorksSession(visible=self.visible)
                model = session.new_part()
                if model is None:
                    raise RuntimeError("新建零件失败")
                
                self.sw = session.sw
                self.model = model
                self.ext = model.Extension
                self.fm = model.FeatureManager
                self.sm = model.SketchManager
                self.connected = True
                self.connection_time = time.time()
                self.last_heartbeat = time.time()
                return True
            except Exception as e:
                self.connected = False
                self.error_history.append({
                    "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "action": "connect",
                    "error": str(e)
                })
                return False
    
    def _disconnect(self):
        """断开连接"""
        with self._thread_lock:
            self.sw = None
            self.model = None
            self.ext = None
            self.fm = None
            self.sm = None
            self.connected = False
    
    def reconnect(self):
        """手动重连"""
        self._disconnect()
        self.reconnect_count += 1
        return self._connect()
    
    def ensure_connected(self):
        """确保连接有效，必要时自动重连"""
        with self._thread_lock:
            if not self.connected or not self._check_com_alive():
                self.reconnect_count += 1
                return self._connect()
            return True
    
    def _heartbeat_loop(self):
        """后台心跳检测循环"""
        while not self._stop_heartbeat.is_set():
            try:
                if self.connected:
                    if not self._check_com_alive():
                        self.connected = False
                        self.error_history.append({
                            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                            "action": "heartbeat",
                            "error": "COM 连接断开，准备重连"
                        })
                
                if not self.connected:
                    self.reconnect_count += 1
                    self._connect()
                
                self.last_heartbeat = time.time()
            except Exception as e:
                self.error_history.append({
                    "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "action": "heartbeat",
                    "error": str(e)
                })
            
            self._stop_heartbeat.wait(self.heartbeat_interval)
    
    def start_heartbeat(self):
        """启动心跳线程"""
        if self._heartbeat_thread is None or not self._heartbeat_thread.is_alive():
            self._stop_heartbeat.clear()
            self._heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
            self._heartbeat_thread.start()
    
    def stop_heartbeat(self):
        """停止心跳线程"""
        self._stop_heartbeat.set()
        if self._heartbeat_thread:
            self._heartbeat_thread.join(timeout=2)
    
    def get_status(self):
        """获取连接状态"""
        with self._thread_lock:
            alive = self._check_com_alive() if self.sw else False
            return {
                "connected": self.connected and alive,
                "com_alive": alive,
                "connection_time": self.connection_time,
                "last_heartbeat": self.last_heartbeat,
                "reconnect_count": self.reconnect_count,
                "uptime_seconds": round(time.time() - self.connection_time, 2) if self.connection_time else 0,
                "model_title": self.model.GetTitle if self.model else None,
                "error_count": len(self.error_history),
                "recent_errors": self.error_history[-5:] if self.error_history else []
            }
    
    async def async_ensure_connected(self):
        """异步版本的确保连接"""
        async with self._async_lock:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, self.ensure_connected)
    
    async def async_get_status(self):
        """异步版本的状态查询"""
        async with self._async_lock:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, self.get_status)
    
    async def async_execute(self, func, *args, **kwargs):
        """异步执行 COM 操作（带锁保护和异常处理）"""
        async with self._async_lock:
            loop = asyncio.get_event_loop()
            
            # 确保连接
            connected = await loop.run_in_executor(None, self.ensure_connected)
            if not connected:
                raise RuntimeError("无法连接到 SolidWorks")
            
            # 执行操作
            try:
                return await loop.run_in_executor(None, lambda: func(*args, **kwargs))
            except Exception as e:
                # 如果是 COM 错误，尝试重连一次
                error_str = str(e).lower()
                if "com" in error_str or "dispatch" in error_str or "rpc" in error_str:
                    self.connected = False
                    connected = await loop.run_in_executor(None, self.reconnect)
                    if connected:
                        return await loop.run_in_executor(None, lambda: func(*args, **kwargs))
                raise


# 全局连接管理器实例
_connection_manager = None


def get_connection_manager(visible=True, heartbeat_interval=5.0):
    """获取全局连接管理器实例"""
    global _connection_manager
    if _connection_manager is None:
        _connection_manager = SolidWorksConnectionManager(
            visible=visible,
            heartbeat_interval=heartbeat_interval
        )
        _connection_manager._connect()
        _connection_manager.start_heartbeat()
    return _connection_manager


def shutdown_connection_manager():
    """关闭连接管理器"""
    global _connection_manager
    if _connection_manager:
        _connection_manager.stop_heartbeat()
        _connection_manager._disconnect()
        _connection_manager = None
