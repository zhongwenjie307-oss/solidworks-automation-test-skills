#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
SolidWorks MCP Server
通过 MCP 协议暴露 SolidWorks COM 自动化能力

支持工具:
- sw_connect: 连接 SolidWorks
- sw_new_part: 新建零件
- sw_extrude_boss: 拉伸凸台
- sw_extrude_cut: 拉伸切除
- sw_revolve_boss: 旋转凸台
- sw_fillet: 圆角
- sw_chamfer: 倒角
- sw_shell: 抽壳
- sw_save: 保存文件
- sw_export: 导出文件
- sw_screenshot: 截图
- sw_get_info: 获取模型信息
"""

import sys
import os
import json
import math
import time
import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

# 添加 skill scripts 到路径
SKILL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                         'codex-skills', 'solidworks-automation', 'scripts')
sys.path.insert(0, SKILL_DIR)

from mcp.server.fastmcp import FastMCP
import pythoncom
from win32com.client import VARIANT

mcp = FastMCP("solidworks-automation")

# ============================================================
# 全局状态
# ============================================================
_g = {
    "sw": None,
    "model": None,
    "ext": None,
    "fm": None,
    "sm": None,
}


def _e():
    return VARIANT(pythoncom.VT_DISPATCH, None)


def mm(val):
    return val / 1000.0


def _connect_sw():
    """连接 SolidWorks"""
    if _g["sw"] is not None:
        return _g["sw"], _g["model"], _g["ext"], _g["fm"], _g["sm"]

    from sw_session import SolidWorksSession
    session = SolidWorksSession(visible=True)
    model = session.new_part()
    if model is None:
        raise RuntimeError("新建零件失败")

    _g["sw"] = session.sw
    _g["model"] = model
    _g["ext"] = model.Extension
    _g["fm"] = model.FeatureManager
    _g["sm"] = model.SketchManager
    return _g["sw"], model, _g["ext"], _g["fm"], _g["sm"]


# ============================================================
# MCP Tools
# ============================================================

@mcp.tool()
def sw_connect() -> str:
    """连接 SolidWorks 并新建零件文档"""
    try:
        sw, model, ext, fm, sm = _connect_sw()
        return json.dumps({
            "status": "success",
            "message": "SolidWorks 已连接并新建零件",
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


@mcp.tool()
def sw_new_part() -> str:
    """新建一个空白零件文档"""
    try:
        _g["sw"] = None  # 强制重新连接
        return sw_connect()
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


@mcp.tool()
def sw_extrude_boss(
    width_mm: float = 50.0,
    height_mm: float = 30.0,
    depth_mm: float = 30.0,
    sketch_plane: str = "前视基准面"
) -> str:
    """创建矩形拉伸凸台"""
    try:
        sw, model, ext, fm, sm = _connect_sw()

        ext.SelectByID2(sketch_plane, "PLANE", 0, 0, 0, False, 0, _e(), 0)
        sm.InsertSketch(True)
        w, h = mm(width_mm) / 2, mm(height_mm) / 2
        sm.CreateCornerRectangle(-w, -h, 0, w, h, 0)
        sm.InsertSketch(True)

        sketch_name = "草图1"
        ext.SelectByID2(sketch_name, "SKETCH", 0, 0, 0, False, 0, _e(), 0)
        fm.FeatureExtrusion3(
            True, False, True, 0, 0, mm(depth_mm), 0,
            False, False, False, False, 0, 0,
            False, False, False, False, True, False, True, 0, 0, False,
        )

        return json.dumps({
            "status": "success",
            "message": f"拉伸凸台创建成功: {width_mm}x{height_mm}x{depth_mm}mm",
            "feature": "凸台-拉伸1"
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


@mcp.tool()
def sw_extrude_cut(
    circle_radius_mm: float = 8.0,
    cut_depth_mm: float = 10.0,
    sketch_plane: str = "前视基准面"
) -> str:
    """创建圆形拉伸切除"""
    try:
        sw, model, ext, fm, sm = _connect_sw()

        ext.SelectByID2(sketch_plane, "PLANE", 0, 0, 0, False, 0, _e(), 0)
        sm.InsertSketch(True)
        sm.CreateCircleByRadius(0, 0, 0, mm(circle_radius_mm))
        sm.InsertSketch(True)

        sketch_name = "草图2"
        ext.SelectByID2(sketch_name, "SKETCH", 0, 0, 0, False, 0, _e(), 0)
        fm.FeatureCut4(
            True, False, False, 1, 0, mm(cut_depth_mm), 0,
            False, False, False, 0, 0.0, False, False,
            False, False, True, 1, True, 0, 0, 0, 0, False, False, False, False
        )

        return json.dumps({
            "status": "success",
            "message": f"拉伸切除创建成功: 半径{circle_radius_mm}mm, 深度{cut_depth_mm}mm",
            "feature": "切除-拉伸1"
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


@mcp.tool()
def sw_revolve_boss(
    inner_radius_mm: float = 5.0,
    outer_radius_mm: float = 20.0,
    height_mm: float = 30.0,
    sketch_plane: str = "前视基准面"
) -> str:
    """创建旋转凸台"""
    try:
        sw, model, ext, fm, sm = _connect_sw()

        ext.SelectByID2(sketch_plane, "PLANE", 0, 0, 0, False, 0, _e(), 0)
        sm.InsertSketch(True)
        sm.CreateCenterLine(0, mm(-5), 0, 0, mm(40), 0)
        sm.CreateLine(mm(inner_radius_mm), 0, 0, mm(outer_radius_mm), 0, 0)
        sm.CreateLine(mm(outer_radius_mm), 0, 0, mm(outer_radius_mm), mm(height_mm), 0)
        sm.CreateLine(mm(outer_radius_mm), mm(height_mm), 0, mm(inner_radius_mm), mm(height_mm), 0)
        sm.CreateLine(mm(inner_radius_mm), mm(height_mm), 0, mm(inner_radius_mm), 0, 0)
        sm.InsertSketch(True)

        sketch_name = "草图3"
        ext.SelectByID2(sketch_name, "SKETCH", 0, 0, 0, False, 0, _e(), 0)
        fm.FeatureRevolve2(
            True, True, False, False, False, False,
            0, 0, 2 * math.pi, 0,
            False, False, 0.0, 0.0,
            0, 0, 0, True, False, True,
        )

        return json.dumps({
            "status": "success",
            "message": f"旋转凸台创建成功: 内径{inner_radius_mm}mm, 外径{outer_radius_mm}mm, 高{height_mm}mm",
            "feature": "旋转1"
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


@mcp.tool()
def sw_fillet(radius_mm: float = 3.0) -> str:
    """创建圆角特征"""
    try:
        sw, model, ext, fm, sm = _connect_sw()
        ext.SelectByID2("", "EDGE", mm(25), 0, mm(15), False, 0, _e(), 0)
        fm.FeatureFillet(195, mm(radius_mm), 0, 0, None, None, None)
        return json.dumps({
            "status": "success",
            "message": f"圆角创建成功: R{radius_mm}mm",
            "feature": "圆角1"
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


@mcp.tool()
def sw_chamfer(distance_mm: float = 2.0) -> str:
    """创建倒角特征"""
    try:
        sw, model, ext, fm, sm = _connect_sw()
        fm.InsertFeatureChamfer(0, 16, mm(distance_mm), 0, 0, 0, 0, 0)
        return json.dumps({
            "status": "success",
            "message": f"倒角创建成功: {distance_mm}mm",
            "feature": "倒角1"
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


@mcp.tool()
def sw_shell(thickness_mm: float = 2.0) -> str:
    """创建抽壳特征"""
    try:
        sw, model, ext, fm, sm = _connect_sw()
        ext.SelectByID2("", "FACE", 0, 0, mm(30), False, 1, _e(), 0)
        model.InsertFeatureShell(mm(thickness_mm), False)
        return json.dumps({
            "status": "success",
            "message": f"抽壳创建成功: 壁厚{thickness_mm}mm",
            "feature": "抽壳1"
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


@mcp.tool()
def sw_save(filepath: str = r"E:\AI-SW-Ansys\model\mcp_output\part.sldprt") -> str:
    """保存当前模型到指定路径"""
    try:
        sw, model, ext, fm, sm = _connect_sw()
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        model.SaveAs3(filepath, 0, 2)
        return json.dumps({
            "status": "success",
            "message": f"模型已保存: {filepath}"
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


@mcp.tool()
def sw_export(
    filepath: str = r"E:\AI-SW-Ansys\model\mcp_output\part.step",
    format_type: str = "STEP"
) -> str:
    """导出模型到指定格式 (STEP/STL/IGES/PDF)"""
    try:
        sw, model, ext, fm, sm = _connect_sw()
        os.makedirs(os.path.dirname(filepath), exist_ok=True)

        format_map = {
            "STEP": (".step", 0),
            "STL": (".stl", 0),
            "IGES": (".igs", 0),
            "PDF": (".pdf", 0),
        }

        if format_type.upper() not in format_map:
            return json.dumps({
                "status": "error",
                "message": f"不支持的格式: {format_type}. 支持: STEP, STL, IGES, PDF"
            }, ensure_ascii=False)

        model.SaveAs3(filepath, 0, 2)
        return json.dumps({
            "status": "success",
            "message": f"模型已导出为 {format_type}: {filepath}"
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


@mcp.tool()
def sw_screenshot(
    filepath: str = r"E:\AI-SW-Ansys\model\mcp_output\screenshot.bmp",
    view_name: str = "isometric",
    width: int = 1600,
    height: int = 1000
) -> str:
    """截取当前模型视图"""
    try:
        sw, model, ext, fm, sm = _connect_sw()
        from sw_review import save_preview
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        save_preview(model, filepath, view_name=view_name, width=width, height=height)
        return json.dumps({
            "status": "success",
            "message": f"截图已保存: {filepath}",
            "view": view_name
        }, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


@mcp.tool()
def sw_get_info() -> str:
    """获取当前模型的基本信息"""
    try:
        sw, model, ext, fm, sm = _connect_sw()

        info = {
            "status": "success",
            "title": model.GetTitle,
            "path": model.GetPathName,
            "feature_count": model.GetFeatureCount,
        }

        try:
            bodies = model.GetBodies2(0, True)
            if bodies:
                body = bodies[0]
                info["body_count"] = len(bodies)
                info["body_type"] = "solid" if body.GetType() == 0 else "sheet"
                info["face_count"] = body.GetFaceCount()
                box = body.GetBodyBox()
                if box and len(box) >= 6:
                    info["bbox_mm"] = {
                        "x": round((box[3] - box[0]) * 1000, 2),
                        "y": round((box[4] - box[1]) * 1000, 2),
                        "z": round((box[5] - box[2]) * 1000, 2),
                    }
        except Exception as e:
            info["body_error"] = str(e)

        return json.dumps(info, ensure_ascii=False)
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False)


@mcp.tool()
def sw_create_box(
    width_mm: float = 50.0,
    height_mm: float = 30.0,
    depth_mm: float = 30.0
) -> str:
    """一键创建长方体（连接+拉伸凸台）"""
    return sw_extrude_boss(width_mm, height_mm, depth_mm)


@mcp.tool()
def sw_create_cylinder(
    radius_mm: float = 25.0,
    height_mm: float = 50.0
) -> str:
    """一键创建圆柱体（连接+旋转凸台）"""
    return sw_revolve_boss(0, radius_mm, height_mm)


# ============================================================
# 主入口
# ============================================================

if __name__ == "__main__":
    print("SolidWorks MCP Server 启动中...", file=sys.stderr)
    mcp.run(transport='stdio')
