"""
SolidWorks 连接工具
提供连接到 SolidWorks 实例的各种方法
"""
import glob
import os
import sys
import time

import pythoncom
import win32com.client
from win32com.client import VARIANT


def _safe_print(*args, **kwargs):
    """安全的打印函数，处理 stdout 被关闭的情况"""
    try:
        import builtins
        builtins.print(*args, **kwargs)
    except (ValueError, OSError):
        pass


DOC_TYPE_MAP = {
    "part": 1,
    "prt": 1,
    "sldprt": 1,
    "assembly": 2,
    "asm": 2,
    "sldasm": 2,
    "drawing": 3,
    "drw": 3,
    "slddrw": 3,
}

DOC_TYPE_LABELS = {
    "part": "零件",
    "assembly": "装配体",
    "drawing": "工程图",
}


def get_com_member(obj, attr_name, *args):
    """
    兼容 pywin32 中"同一成员在不同环境下可能是属性也可能是方法"的情况。

    参数:
        obj: COM 对象
        attr_name: 成员名称
        *args: 当成员可调用时传入的参数

    返回:
        成员值或调用结果
    """
    member = getattr(obj, attr_name)
    return member(*args) if callable(member) else member


def create_empty_dispatch_variant():
    """创建可传给 COM 接口的空 Dispatch 参数。"""
    return VARIANT(pythoncom.VT_DISPATCH, None)


def normalize_doc_type(doc_type):
    """
    规范化文档类型名称。

    参数:
        doc_type: "part"、"assembly"、"drawing" 或常见缩写/扩展名

    返回:
        (name, enum_value) 元组
    """
    key = str(doc_type).strip().lower().lstrip(".")
    enum_value = DOC_TYPE_MAP.get(key)
    if enum_value is None:
        raise ValueError(f"未知文档类型: {doc_type}")

    name_map = {1: "part", 2: "assembly", 3: "drawing"}
    return name_map[enum_value], enum_value


def _expand_path(file_path):
    """展开用户目录和环境变量，并返回绝对路径。"""
    return os.path.abspath(os.path.expandvars(os.path.expanduser(file_path)))


def _ensure_parent_dir(file_path):
    """确保输出文件的父目录存在。"""
    parent = os.path.dirname(_expand_path(file_path))
    if parent:
        os.makedirs(parent, exist_ok=True)


# 全局变量存储已连接的 SolidWorks 实例
_sw_instance = None

def connect_solidworks(version=None, wait_seconds=5, visible=True, force_new=False):
    """
    连接到 SolidWorks 实例。

    参数:
        version: SolidWorks 版本年份（如 2024），None 则自动检测
        wait_seconds: 启动新实例后等待秒数
        visible: 启动新实例后是否显示窗口
        force_new: 是否强制创建新实例（默认 False，优先复用已有实例）

    返回:
        (sw, model) 元组，model 可能为 None（无打开的文档时）
    """
    global _sw_instance

    # 如果已有连接且不强制新建，直接返回
    if _sw_instance is not None and not force_new:
        try:
            # 检查连接是否仍然有效
            version_info = _sw_instance.RevisionNumber
            _safe_print(f"复用已有的 SolidWorks 连接（版本: {version_info}）")
            model = _sw_instance.ActiveDoc
            if model:
                doc_types = {1: "零件", 2: "装配体", 3: "工程图"}
                doc_type = get_com_member(model, "GetType")
                title = get_com_member(model, "GetTitle")
                _safe_print(f"当前文档: {title} (类型: {doc_types.get(doc_type, '未知')})")
            else:
                _safe_print("当前没有打开的文档")
            return _sw_instance, model
        except Exception:
            _sw_instance = None  # 连接已失效，需要重新连接

    sw = None
    prog_id = "SldWorks.Application"
    if version:
        revision = (version - 2000) + 8
        prog_id = f"SldWorks.Application.{revision}"

    # 优先连接已运行的实例
    if not force_new:
        try:
            sw = win32com.client.GetActiveObject(prog_id)
            _safe_print("已连接到运行中的 SolidWorks 实例")
        except Exception:
            try:
                sw = win32com.client.GetActiveObject("SldWorks.Application")
                _safe_print("已连接到运行中的 SolidWorks 实例（通用 ProgID）")
            except Exception:
                pass

    # 如果没有找到运行中的实例，创建新实例
    if sw is None:
        # 使用 Dispatch 而不是 DispatchEx，优先复用现有实例
        try:
            sw = win32com.client.Dispatch(prog_id)
            _safe_print(f"通过 Dispatch 连接到 SolidWorks（ProgID: {prog_id}）")
        except Exception:
            sw = win32com.client.DispatchEx(prog_id)
            sw.Visible = visible
            _safe_print(f"启动了新的 SolidWorks 实例（ProgID: {prog_id}）")
            time.sleep(wait_seconds)

    _sw_instance = sw
    model = sw.ActiveDoc
    if model:
        doc_types = {1: "零件", 2: "装配体", 3: "工程图"}
        doc_type = get_com_member(model, "GetType")
        title = get_com_member(model, "GetTitle")
        _safe_print(f"当前文档: {title} (类型: {doc_types.get(doc_type, '未知')})")
    else:
        _safe_print("当前没有打开的文档")

    return sw, model


def get_sw_version(sw):
    """获取 SolidWorks 版本信息。"""
    rev = get_com_member(sw, "RevisionNumber")
    major = int(rev.split(".")[0])
    year = major - 8 + 2000
    return {"revision": rev, "year": year, "major": major}


def find_template(sw, doc_type="part"):
    """
    自动查找 SolidWorks 文档模板。

    参数:
        sw: SolidWorks 应用对象
        doc_type: "part" | "assembly" | "drawing"

    返回:
        模板文件路径字符串
    """
    doc_type, _ = normalize_doc_type(doc_type)

    type_map = {
        "part": (sw.GetUserPreferenceStringValue(24), "*.prtdot"),
        "assembly": (sw.GetUserPreferenceStringValue(25), "*.asmdot"),
        "drawing": (sw.GetUserPreferenceStringValue(26), "*.drwdot"),
    }

    default_path, pattern = type_map.get(doc_type, type_map["part"])
    if default_path:
        for candidate_root in str(default_path).split(";"):
            candidate_root = _expand_path(candidate_root.strip().strip('"'))
            if not candidate_root:
                continue

            if os.path.isfile(candidate_root):
                return candidate_root

            if os.path.isdir(candidate_root):
                matches = glob.glob(os.path.join(candidate_root, pattern))
                if matches:
                    return matches[0]

    search_dirs = [
        r"C:\ProgramData\SolidWorks\SOLIDWORKS *\templates",
        r"C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS\lang\chinese-simplified",
        r"C:\Program Files\SOLIDWORKS Corp\SOLIDWORKS\lang\english",
    ]
    for search_dir in search_dirs:
        matches = glob.glob(os.path.join(os.path.expandvars(search_dir), pattern))
        if matches:
            return matches[0]

    raise FileNotFoundError(f"无法找到 {doc_type} 模板文件，请手动指定路径")


def new_document(sw, doc_type="part", template_path=None):
    """
    创建新文档。

    参数:
        sw: SolidWorks 应用对象
        doc_type: "part" | "assembly" | "drawing"
        template_path: 模板路径，None 则自动查找

    返回:
        新建的 IModelDoc2 对象
    """
    doc_type, _ = normalize_doc_type(doc_type)
    if not template_path:
        template_path = find_template(sw, doc_type)
    else:
        template_path = _expand_path(template_path)

    model = sw.NewDocument(template_path, 0, 0, 0)
    if model is None:
        for _ in range(20):
            model = sw.ActiveDoc
            if model is not None:
                break
            time.sleep(0.25)

    if model is None:
        raise RuntimeError(f"创建{DOC_TYPE_LABELS.get(doc_type, doc_type)}文档失败，SolidWorks 未返回活动文档")

    _safe_print(f"已创建新{DOC_TYPE_LABELS.get(doc_type, doc_type)}文档")
    return model


def open_document(sw, file_path, read_only=False, silent=False, raise_on_error=False):
    """
    打开已有文档。

    参数:
        sw: SolidWorks 应用对象
        file_path: 文件完整路径
        read_only: 是否以只读模式打开
        silent: 是否静默打开
        raise_on_error: 打开失败时是否抛出异常

    返回:
        IModelDoc2 对象
    """
    file_path = _expand_path(file_path)
    if not os.path.exists(file_path):
        message = f"文件不存在: {file_path}"
        if raise_on_error:
            raise FileNotFoundError(message)
        _safe_print(message)
        return None

    ext = os.path.splitext(file_path)[1].lower()
    type_map = {".sldprt": 1, ".sldasm": 2, ".slddrw": 3, ".step": 1, ".stp": 1, ".igs": 1, ".iges": 1}
    doc_type = type_map.get(ext, 1)

    errors = VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
    warnings = VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
    options = 2 if read_only else 0  # swOpenDocOptions_ReadOnly = 2
    if silent:
        options |= 1  # swOpenDocOptions_Silent = 1

    model = sw.OpenDoc6(file_path, doc_type, options, "", errors, warnings)
    if model:
        _safe_print(f"已打开: {file_path}")
    else:
        message = f"打开失败, 错误码: {errors.value}, 警告码: {warnings.value}"
        if raise_on_error:
            raise RuntimeError(message)
        _safe_print(message)
    return model


def open_document_stable(sw, file_path, read_only=False, silent=True, raise_on_error=False):
    """
    More defensive document opener that prefers GetOpenDocSpec/OpenDoc7.
    """
    file_path = _expand_path(file_path)
    if not os.path.exists(file_path):
        message = f"文件不存在: {file_path}"
        if raise_on_error:
            raise FileNotFoundError(message)
        _safe_print(message)
        return None

    errors = VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
    warnings = VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)

    try:
        docspec = sw.GetOpenDocSpec(file_path)
        if docspec is not None:
            try:
                docspec.ReadOnly = bool(read_only)
            except Exception:
                pass
            try:
                docspec.Silent = bool(silent)
            except Exception:
                pass
            model = sw.OpenDoc7(docspec)
            if model:
                _safe_print(f"已打开: {file_path}")
                return model
    except Exception:
        pass

    options = 2 if read_only else 0
    if silent:
        options |= 1
    ext = os.path.splitext(file_path)[1].lower()
    type_map = {".sldprt": 1, ".sldasm": 2, ".slddrw": 3, ".step": 1, ".stp": 1, ".igs": 1, ".iges": 1}
    doc_type = type_map.get(ext, 1)
    model = sw.OpenDoc6(file_path, doc_type, options, "", errors, warnings)
    if model:
        _safe_print(f"已打开: {file_path}")
        return model

    message = f"打开失败, 错误码: {errors.value}, 警告码: {warnings.value}"
    if raise_on_error:
        raise RuntimeError(message)
    _safe_print(message)
    return None


def save_document(model, file_path=None):
    """
    保存文档。

    参数:
        model: IModelDoc2 对象
        file_path: 另存为路径，None 则保存到当前位置

    返回:
        bool 成功/失败
    """
    errors = VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)
    warnings = VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0)

    if file_path:
        file_path = _expand_path(file_path)
        _ensure_parent_dir(file_path)
        success = model.Extension.SaveAs(
            file_path, 0, 1, create_empty_dispatch_variant(), errors, warnings
        )
    else:
        success = model.Save3(1, errors, warnings)

    if success:
        _safe_print(f"保存成功: {file_path or get_com_member(model, 'GetPathName')}")
    else:
        _safe_print(f"保存失败, 错误码: {errors.value}, 警告码: {warnings.value}")
    return bool(success)


def mm(value):
    """毫米转米（SolidWorks API 单位）。"""
    return value / 1000.0


def deg(value):
    """角度转弧度。"""
    import math
    return value * math.pi / 180.0
