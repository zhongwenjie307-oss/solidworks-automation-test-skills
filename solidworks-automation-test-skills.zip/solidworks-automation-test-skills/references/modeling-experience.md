# SolidWorks 自动化建模经验总结

> 基于 2026-06-17 实测验证，使用 Python pywin32 COM 接口控制 SolidWorks 2024 自动化建模的完整经验库。

## 一、核心发现

### 1.1 pywin32 COM 代理的特殊行为

SolidWorks API 通过 pywin32 调用时，存在大量"返回值不可靠"的情况：

| 现象 | 实际情况 | 应对策略 |
|------|----------|----------|
| API 返回 None | 实际已成功执行 | 通过检查模型状态确认（面数、特征树） |
| `model.FirstFeature` 返回收藏文件夹 | 不是特征根节点 | 使用 `model.FeatureByName("中文名")` 查找 |
| `feat.GetNextFeature` 返回 None | 无法链式遍历 | 用 FeatureByName + 前缀枚举发现特征 |
| `body.GetVolume()` 报错 | pywin32 COM 代理不支持 | 用 `GetFaceCount()` + `GetBodyBox()` 代替 |
| `body.GetFaces()` 返回 tuple | 元素不是标准 IFace2 | 需要特殊处理或避免直接遍历 |
| `model.GetFeatureCount` 是属性 | 不是方法，直接访问 | `count = model.GetFeatureCount` |

### 1.2 验证结果统计

**已验证命令 (18个)**:
- 基础操作: 新建零件、基准面选择、保存/导出、截图预览
- 草图: 矩形、圆、弧、椭圆、多边形、点、文字、槽口、中心线
- 特征: 拉伸凸台、拉伸切除、旋转凸台、抽壳、圆角、倒角
- 高级: 参考轴、中面拉伸、草图约束

**未通过命令 (5个)**:
- 样条曲线 (CreateSpline2)
- 镜像特征 (InsertMirrorFeature2)
- 线性阵列 (FeatureLinearPattern3)
- 圆形阵列 (FeatureCircularPattern)
- 筋特征 (InsertRib)

## 二、建模模式库

### 2.1 旋转体建模（瓶、轴、圆柱容器）

```python
# 适用: 矿泉水瓶、可乐瓶、花瓶、圆柱杯、轴类
sm = model.SketchManager
fm = model.FeatureManager

# 1. 选择基准面，进入草图
ext.SelectByID2("前视基准面", "PLANE", 0, 0, 0, False, 0, _e(), 0)
sm.InsertSketch(True)

# 2. 中心线 (旋转轴) - 必须用 CreateCenterLine
sm.CreateCenterLine(0, mm(-10), 0, 0, H + mm(10), 0)

# 3. 封闭轮廓 - 关键: 不能经过原点!
profile = [(mm(1), 0), (R, 0), (R, mm(15)), ..., (mm(1), H)]
for i in range(len(profile)):
    x1, y1 = profile[i]
    x2, y2 = profile[(i + 1) % len(profile)]
    sm.CreateLine(x1, y1, 0, x2, y2, 0)

sm.InsertSketch(True)

# 4. 选择草图并旋转
ext.SelectByID2("草图1", "SKETCH", 0, 0, 0, False, 0, _e(), 0)
fm.FeatureRevolve2(True, True, False, False, False, False,
                   0, 0, 2*math.pi, 0, False, False, 0.0, 0.0,
                   0, 0, 0, True, False, True)

# 5. 抽壳 (返回None但实际生效)
model.InsertFeatureShell(mm(0.3), False)  # 完全封闭抽壳
```

**关键经验**:
- 轮廓起点用 `(mm(1), 0)` 而非 `(0, 0)`，避免与中心线重叠
- 旋转生成实体而非曲面的条件: 轮廓封闭 + 不与中心线交叉
- 抽壳后检查面数变化确认是否生效

### 2.2 箱体建模（壳体、外壳、盒子）

```python
# 适用: 电子外壳、齿轮箱、机箱、支架
# 1. 拉伸底板
ext.SelectByID2("上视基准面", "PLANE", 0, 0, 0, False, 0, _e(), 0)
sm.InsertSketch(True)
sketch_rectangle(model, -L/2, -W/2, L, W)
sm.InsertSketch(True)
ext.SelectByID2("草图1", "SKETCH", 0, 0, 0, False, 0, _e(), 0)
extrude_boss(model, "草图1", H)

# 2. 抽壳
model.InsertFeatureShell(mm(2), False)

# 3. 切除开口 (注意: 需要正确选择草图)
# extrude_cut 在某些情况下可能失败，建议直接用 FeatureExtrusion3
```

### 2.3 孔/切除建模

```python
# 圆孔阵列 (手动循环，因为阵列命令未通过)
for angle in [i * 2*math.pi/n_holes for i in range(n_holes)]:
    cx = center_x + pitch_r * math.cos(angle)
    cy = center_y + pitch_r * math.sin(angle)
    # 在新草图中画圆并切除
```

## 三、可靠代码模式

### 3.1 特征发现模式

```python
def discover_features(model):
    """可靠的特征发现 - 使用 FeatureByName + 中文前缀"""
    found = []
    patterns = ["凸台-拉伸", "切除-拉伸", "旋转", "抽壳", "圆角",
                "倒角", "镜像", "线性阵列", "圆周阵列", "筋",
                "基准轴", "草图"]
    for prefix in patterns:
        for i in range(1, 30):
            try:
                feat = model.FeatureByName(f"{prefix}{i}")
                if feat:
                    found.append({"name": feat.Name, "type": feat.GetTypeName2, "obj": feat})
            except:
                pass
    return found
```

### 3.2 实体验证模式

```python
def verify_solid_body(model, min_faces=1):
    """验证模型是否包含实体"""
    bodies = model.GetBodies2(0, True)
    if bodies and len(bodies) > 0:
        body = bodies[0]
        return body.GetType() == 0 and body.GetFaceCount() >= min_faces
    return False

def get_model_dimensions(model):
    """获取模型尺寸"""
    bodies = model.GetBodies2(0, True)
    if bodies and len(bodies) > 0:
        box = bodies[0].GetBodyBox()
        dx = (box[3] - box[0]) * 1000  # 转mm
        dy = (box[4] - box[1]) * 1000
        dz = (box[5] - box[2]) * 1000
        return dx, dy, dz
    return 0, 0, 0
```

### 3.3 安全截图模式

```python
def safe_screenshot(model, output_path, view="isometric", w=1600, h=1000):
    """安全截图 - 使用正确的3参数 SaveBMP"""
    from sw_review import save_preview
    try:
        save_preview(model, output_path, view_name=view, width=w, height=h)
        return True
    except Exception as e:
        print(f"截图失败: {e}")
        return False
```

## 四、失败命令的替代方案

| 失败命令 | 替代方案 |
|----------|----------|
| CreateSpline2 (样条曲线) | 用多段 CreateLine 近似曲线，增加线段数提高精度 |
| InsertMirrorFeature2 (镜像) | 手动在对称位置创建相同几何 |
| FeatureLinearPattern3 (线性阵列) | 用循环在计算位置创建相同特征 |
| FeatureCircularPattern (圆形阵列) | 用循环 + 三角函数计算位置 |
| InsertRib (筋) | 用拉伸凸台 + 草图线代替 |

## 五、建模流程最佳实践

### 5.1 推荐建模顺序

1. **新建零件** -> `session.new_part()`
2. **绘制草图** -> 选择基准面 -> 画轮廓 -> 退出草图
3. **创建基础特征** -> 拉伸凸台 或 旋转凸台
4. **添加细节特征** -> 抽壳 -> 切除 -> 圆角/倒角
5. **验证实体** -> `GetBodies2` + `GetFaceCount`
6. **保存文件** -> `SaveAs3`
7. **截图确认** -> `save_preview`

### 5.2 常见陷阱

1. **单位**: API 使用米，必须用 `mm()` 转换
2. **草图选择**: `SelectByID2("草图1", "SKETCH")` 用于拉伸/旋转前选择
3. **特征选择**: `model.FeatureByName("凸台-拉伸1").Select2(False, 4)` 用于后续操作
4. **面选择**: 坐标选择面可能不准确，建议用特征操作代替
5. **中文特征名**: SolidWorks 中文版生成中文特征名，FeatureByName 只支持中文

### 5.3 复刻已有模型的策略

1. **分析目标模型**: 确定主要特征类型（旋转体/箱体/组合体）
2. **提取关键尺寸**: 从模型文件名或参考图获取尺寸
3. **分解建模步骤**: 将复杂模型分解为多个简单特征
4. **逐步验证**: 每步操作后检查实体状态
5. **截图对比**: 生成多角度截图与原始模型对比

## 六、已完成的复刻案例

| 模型 | 尺寸 | 使用命令 | 文件 |
|------|------|----------|------|
| 矿泉水瓶 (农夫山泉) | 65x220x65mm | 旋转+抽壳 | water_bottle_500ml_v7.sldprt |
| 可乐瓶 | 70x210x70mm | 旋转+抽壳 | coke_bottle_replicated.sldprt |
| 电子外壳 | 100x60x30mm | 拉伸+抽壳+圆角 | plastic_enclosure_replicated.sldprt |

## 七、后续改进方向

1. **修复失败命令**: 研究更高版本 API (InsertMirrorFeature4, FeatureLinearPattern5 等)
2. **面遍历改进**: 找到可靠的方式遍历 IBody2::GetFaces() 返回的面
3. **样条曲线替代**: 实现多段线近似曲线的辅助函数
4. **装配体支持**: 扩展到多零件装配
5. **工程图生成**: 自动生成三视图和尺寸标注
6. **自然语言接口**: 完善 Agent Skill 的 NLU 解析和执行能力
