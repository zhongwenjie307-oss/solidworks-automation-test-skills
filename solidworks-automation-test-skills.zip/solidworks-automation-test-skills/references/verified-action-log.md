# SolidWorks 已验证动作记录

下面这些动作是我在本机 SolidWorks 2024 里用 Python COM 实测跑通的，记录的是实际可复用的代码片段，而不是推测。

## 1. 新建零件

```python
sw, model = connect_solidworks()
model = new_document(sw, "part")
```

结果：

- 新建出 `零件1`
- 进入可编辑状态

## 2. 选择基准面并进入草图

```python
start_sketch(model, "Front Plane")
```

在当前简体中文环境下，也能稳定识别：

- `前视基准面`
- `上视基准面`
- `右视基准面`

结果：

- `Front Plane` / 中文基准面都能命中真实平面
- 草图可以正常进入

## 3. 草图矩形 + 拉伸凸台

```python
start_sketch(model, "Front Plane")
sketch_rectangle(model, 0, 0, mm(40), mm(20))
end_sketch(model)
extrude_boss(model, "Sketch1", mm(8))
```

结果：

- 成功生成拉伸实体
- `extrude_boss` 在当前环境中可稳定复现

## 4. 草图圆 + 拉伸切除

```python
start_sketch(model, "Top Plane")
sketch_circle(model, 0, 0, mm(8))
end_sketch(model)
model.ClearSelection2(True)
extrude_cut(model, "Sketch2", 0)
```

结果：

- 成功生成切除特征
- 当前简体中文环境中，第二个草图以 `Sketch2` 命中成功

## 5. 保存文件

```python
save_document(model, r"E:\\AI-SW-Ansys\\model\\python_action_test.sldprt")
```

结果：

- 保存成功

## 6. 预览自检

```python
report, report_path = run_review(
    model,
    r"E:\\AI-SW-Ansys\\model\\review",
    basename="python_action_test",
    expected_outputs=[r"E:\\AI-SW-Ansys\\model\\python_action_test.sldprt"],
)
```

结果：

- 生成 `review_report.json`
- 生成预览图
- `status = warn`
- `score = 92`
- `previews_created = True`
- `previews_not_blank = True`
- `expected_outputs_exist = True`

## 7. 圆角

```python
select_entity(model, "Edge", 0)
fillet(model, mm(2))
```

结果：

- 成功生成 `圆角1`
- 特征树可见圆角特征
- 重建通过

## 8. 倒角

```python
select_entity(model, "Edge", 1)
chamfer(model, mm(1))
```

结果：

- 成功生成 `倒角1`
- 特征树可见倒角特征
- 重建通过

## 9. 抽壳

```python
model.InsertFeatureShell(mm(2), False)
```

结果：

- InsertFeatureShell 返回 None 但**实际生效**
- 面数从 6 变为 12（说明生成了内壁面）
- 特征树中出现 `抽壳1`
- **重要**: 许多 SolidWorks API 通过 pywin32 调用时返回 None，但实际已成功执行。需要通过检查模型状态（面数、特征树）来确认。

## 10. 草图圆弧

```python
start_sketch(model, "Front Plane")
sketch_arc(model, 0, 0, 0.01, 0, 0, 0.01)
end_sketch(model)
```

结果：

- 成功生成 `草图2`
- 特征树可见新的草图条目
- 重建通过

## 11. 草图椭圆

```python
start_sketch(model, "Front Plane")
add_ellipse(model, 0, 0, 0.02, 0, 0, 0.01)
end_sketch(model)
```

结果：

- 成功生成 `草图3`
- 特征树可见新的草图条目
- 重建通过

## 12. 草图正多边形

```python
start_sketch(model, "Front Plane")
add_polygon(model, 0, 0, 0.02, sides=6)
end_sketch(model)
```

结果：

- 成功生成 `草图4`
- 特征树可见新的草图条目
- 重建通过

## 13. 草图点

```python
start_sketch(model, "Front Plane")
add_point(model, 0.006, 0.006)
end_sketch(model)
```

结果：

- 成功生成 `草图5`
- 特征树可见新的草图条目
- 重建通过

## 14. 草图文字

```python
start_sketch(model, "Front Plane")
add_text(model, "A", 0, 0.025, height=0.005)
end_sketch(model)
```

结果：

- 成功生成 `草图6`
- 特征树可见新的草图条目
- 重建通过

## 15. 旋转凸台 (CreateCenterLine + FeatureRevolve2)

```python
sm = model.SketchManager
fm = model.FeatureManager

# 选择基准面并进入草图
ext.SelectByID2("前视基准面", "PLANE", 0, 0, 0, False, 0, _e(), 0)
sm.InsertSketch(True)

# 中心线 (旋转轴)
sm.CreateCenterLine(0, mm(-10), 0, 0, H + mm(10), 0)

# 封闭轮廓 (关键: 不经过原点!)
profile = [(mm(1), 0), (R, 0), (R, mm(15)), ..., (mm(1), H)]
for i in range(len(profile)):
    x1, y1 = profile[i]
    x2, y2 = profile[(i + 1) % len(profile)]
    sm.CreateLine(x1, y1, 0, x2, y2, 0)

sm.InsertSketch(True)

# 选择草图并旋转
ext.SelectByID2("草图1", "SKETCH", 0, 0, 0, False, 0, _e(), 0)
feature = fm.FeatureRevolve2(
    True, True, False, False, False, False,
    0, 0, 2 * math.pi, 0,
    False, False, 0.0, 0.0,
    0, 0, 0, True, False, True,
)
```

结果：

- 成功生成旋转实体
- 实体类型: solid, 面数: 10
- 边界框: 65.0 x 220.0 x 65.0 mm (农夫山泉水瓶)
- **关键**: 轮廓不能与中心线重叠（不经过原点），否则生成曲面而非实体

## 16. 草图槽口 (CreateSketchSlot)

```python
sm = model.SketchManager
sm.CreateSketchSlot(
    0, 0, mm(8),           # slot_creation_type, slot_length_type, width
    mm(0), mm(0), 0,       # x1, y1, z1 (起点)
    mm(30), mm(0), 0,      # x2, y2, z2 (终点)
    mm(15), mm(10), 0,     # x3, y3, z3 (宽度方向)
    1, False               # center_arc_direction, add_dimension
)
```

结果：

- 成功创建槽口草图
- 返回 CDispatch 对象

## 17. 草图中心线 (CreateCenterLine)

```python
sm.CreateCenterLine(mm(0), mm(-5), 0, mm(0), mm(50), 0)
```

结果：

- 成功创建中心线
- 返回 CDispatch 对象
- 用于旋转特征的旋转轴定义

## 18. 参考轴 (InsertAxis2)

```python
ext.SelectByID2("前视基准面", "PLANE", 0, 0, 0, False, 0, _e(), 0)
ext.SelectByID2("上视基准面", "PLANE", 0, 0, 0, True, 0, _e(), 0)
model.InsertAxis2(True)
```

结果：

- 成功创建参考轴
- 返回 True
- 特征树中出现 `基准轴1`

## 19. 中面拉伸 (FeatureExtrusion3 MidPlane)

```python
# 选择草图 (通过 FeatureByName)
feat = model.FeatureByName("草图N")
feat.Select2(False, 0)

fm.FeatureExtrusion3(
    True, False, True,     # Sd, Flip, Dir
    6, 0,                  # T1=swEndCondMidPlane, T2
    mm(20), 0.0,           # D1=总深度, D2
    False, False, False, False, 0.0, 0.0,  # DraftAngle等
    False, False, False, False,  # Offset等
    True, False, True,     # Merge, UseFeatScope, UseAutoSelect
    0, 0.0, False          # T0, StartOffset, FlipStartOffset
)
```

结果：

- 成功创建对称拉伸
- 特征树中出现新的 `凸台-拉伸N`
- **注意**: 需通过 FeatureByName 选择草图，不能用 SelectByID2("草图N", "SKETCH")

## 20. 草图约束 (SketchAddConstraints)

```python
# 先画线
sm.CreateLine(mm(0), mm(0), 0, mm(20), mm(0), 0)
sm.CreateLine(mm(0), mm(0), 0, mm(0), mm(20), 0)

# 选择线段
ext.SelectByID2("", "SEGMENT", mm(10), mm(0), 0, False, 0, _e(), 0)

# 添加水平约束
model.SketchAddConstraints("sgHORIZONTAL")
```

结果：

- SketchAddConstraints 返回 None 但实际生效
- 常用约束类型: "sgFIXED", "sgHORIZONTAL", "sgVERTICAL", "sgCOLLINEAR", "sgPARALLEL", "sgPERPENDICULAR", "sgTANGENT", "sgCONCENTRIC", "sgEQUAL", "sgSYMMETRIC", "sgMIDPOINT", "sgCOINCIDENT"

## 21. 截图 (SaveBMP)

```python
from sw_review import save_preview
save_preview(model, output_path, view_name="isometric", width=1600, height=1000)
```

结果：

- SaveBMP 正确参数: `model.SaveBMP(path, width, height)` (3个参数)
- 之前错误用法: `model.SaveBMP(path, 0, 0, 0)` (4个参数，报错)

## 22. 实体检测 (GetBodies2)

```python
bodies_tuple = model.GetBodies2(0, True)  # 返回 tuple
body = bodies_tuple[0]
body_type = body.GetType()       # 0=solid, 1=sheet
face_count = body.GetFaceCount() # 面数
box = body.GetBodyBox()          # 6值: min_x,min_y,min_z,max_x,max_y,max_z
```

结果：

- GetBodies2 返回 Python tuple (不是 list)
- body.GetVolume() 在 pywin32 中**不可用** (报 "GetBodies2.GetVolume" 错误)
- body.GetMassProperties(True) 可用，返回 12 值 tuple
- body.GetType() == 0 表示实体

## 23. 特征发现 (FeatureByName)

```python
# model.FirstFeature 在 pywin32 中返回收藏文件夹，不可靠
# 使用 FeatureByName 按名称查找:
feat = model.FeatureByName("凸台-拉伸1")  # 返回 CDispatch 或 None
feat.Name       # "凸台-拉伸1"
feat.GetTypeName2  # "Extrusion"

# 发现所有特征:
for prefix in ["凸台-拉伸", "切除-拉伸", "旋转", "抽壳", "圆角", "倒角",
                "镜像", "线性阵列", "圆周阵列", "筋", "基准轴", "草图"]:
    for i in range(1, 30):
        feat = model.FeatureByName(f"{prefix}{i}")
        if feat:
            print(feat.Name, feat.GetTypeName2)

# model.GetFeatureCount 返回特征总数 (int)
count = model.GetFeatureCount  # 属性，不是方法
```

结果：

- `model.FeatureByName("中文名")` 可靠工作
- `model.FeatureByName("英文名")` 不工作 (如 "Sketch1")
- `model.GetFeatureCount` 是属性 (返回 int)，不是方法
- `feat.GetNextFeature` 在 pywin32 中为 None，不可用于遍历

---

## 未通过的动作

### 草图样条 (CreateSpline2)

```python
import array
pt_array = array.array('d')
for x, y in [(mm(0), mm(0)), (mm(10), mm(15)), (mm(20), mm(10))]:
    pt_array.extend([x, y, 0.0])
sm.CreateSpline2(pt_array, False)  # 始终返回 None
```

- CreateSpline2 在当前环境始终返回 None
- 替代方案: 使用多段 CreateLine 近似曲线

### 镜像特征 (InsertMirrorFeature2)

```python
feat.Select2(False, 4)
ext.SelectByID2("右视基准面", "PLANE", 0, 0, 0, True, 1, _e(), 0)
fm.InsertMirrorFeature2(False, False, False, False, 0)  # 返回 None，未生效
```

- 返回 None 且未在特征树中生成镜像特征
- 可能需要额外参数或不同版本 API

### 线性阵列 (FeatureLinearPattern3)

```python
feat.Select2(False, 4)
axis.Select2(True, 1)
fm.FeatureLinearPattern3(mm(40), 0.0, 3, 1, False, False, "", "", False, False)  # 返回 None
```

- 返回 None 且未生成阵列特征

### 圆形阵列 (FeatureCircularPattern)

```python
feat.Select2(False, 4)
axis.Select2(True, 1)
fm.FeatureCircularPattern(4, 2*math.pi, True, True)  # 返回 COMObject 但未生效
```

- 返回 COMObject 但未在特征树中找到对应特征

### 筋特征 (InsertRib)

```python
sketch_feat.Select2(False, 0)
fm.InsertRib(False, False, mm(3), 0, False, False, False, 0.0, True, False)  # 返回 None
```

- 返回 None 且未生成筋特征

---

## pywin32 COM 关键经验

1. **API 返回 None 不代表失败**: InsertFeatureShell、SketchAddConstraints 等返回 None 但实际生效。通过检查模型状态确认。
2. **model.FirstFeature 不可靠**: 返回收藏文件夹而非特征根。使用 FeatureByName 按名称查找。
3. **model.GetFeatureCount 是属性**: 直接访问 `model.GetFeatureCount` (不是方法调用)。
4. **feat.GetNextFeature 不可用**: pywin32 中为 None。无法通过链式遍历特征树。
5. **body.GetVolume() 不可用**: pywin32 COM 代理不支持。用 GetFaceCount + GetBodyBox 代替。
6. **SaveBMP 3参数**: `model.SaveBMP(path, width, height)`，不是 4 参数。
7. **旋转轮廓不能过原点**: 使用 CreateCenterLine 时，轮廓不能与中心线重叠。
8. **中文特征名可用**: FeatureByName("凸台-拉伸1") 工作，FeatureByName("Boss-Extrude1") 不工作。
